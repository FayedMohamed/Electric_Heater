/*
 * GINT_HW.h
 *
 * Created: 10/7/2022 10:11:45 PM
 *  Author: User
 */ 


#ifndef GINT_HW_H_
#define GINT_HW_H_

#include "STD_Types.h"

#define SREG_R *((volatile uint8*)0x5F)


#endif /* GINT_HW_H_ */