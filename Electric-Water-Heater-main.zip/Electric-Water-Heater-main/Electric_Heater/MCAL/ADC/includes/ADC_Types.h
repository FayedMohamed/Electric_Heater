/*
 * ADC_Types.h
 *
 * Created: 10/8/2022 9:44:29 PM
 *  Author: user
 */ 


#ifndef ADC_TYPES_H_
#define ADC_TYPES_H_

typedef enum{
	ADC_Channel0=0,
	ADC_Channel1,
	ADC_Channel2,
	ADC_Channel3,
	ADC_Channel4,
	ADC_Channel5,
	ADC_Channel6,
	ADC_Channel7
	}ADC_ChannelType;


#endif /* ADC_TYPES_H_ */