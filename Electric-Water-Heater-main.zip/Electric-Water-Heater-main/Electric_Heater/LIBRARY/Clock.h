/*
 * Clock.h
 *
 * Created: 10/7/2022 6:44:59 AM
 *  Author: User
 */ 


#ifndef CLOCK_H_
#define CLOCK_H_

#define F_CPU 16000000UL
#include "util/delay.h"


#endif /* CLOCK_H_ */